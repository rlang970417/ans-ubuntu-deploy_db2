You need to replace the supplied Db2 archive with the one you downloaded from IBM Passport.
